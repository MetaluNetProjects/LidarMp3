# GD3300
 Biblioteca para mp3 Serial / audio_trigger board (GD3300)
